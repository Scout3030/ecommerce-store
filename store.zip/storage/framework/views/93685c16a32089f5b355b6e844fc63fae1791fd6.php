<?php $__env->startSection('content'); ?>

<?php echo $__env->make('shared.breadcrumb', ['title' => 'Carrito'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--================Cart Area =================-->
<section class="cart_area">
	<div class="container">
		<cart-page></cart-page>
	</div>
</section>
<!--================End Cart Area =================-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\store\resources\views/cart.blade.php ENDPATH**/ ?>