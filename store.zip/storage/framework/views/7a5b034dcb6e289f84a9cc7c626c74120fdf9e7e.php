<li class="nav-item">
  <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
     onclick="event.preventDefault();
     document.getElementById('logout-form').submit();"
  >
      <?php echo e(__("Cerrar sesión")); ?>

  </a>

  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
      <?php echo csrf_field(); ?>
  </form>
</li>
<?php /**PATH C:\laragon\www\store\resources\views/partials/navigation/logged.blade.php ENDPATH**/ ?>