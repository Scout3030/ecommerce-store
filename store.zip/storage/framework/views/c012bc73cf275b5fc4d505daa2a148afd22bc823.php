<!--================ Start Header Menu Area =================-->
<header class="header_area">
  <div class="main_menu">
    <nav class="navbar navbar-expand-lg navbar-light">
      <div class="container">
        <a class="navbar-brand logo_h" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('assets/img/organza.pe-logo.png')); ?>" alt=""></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <div class="collapse navbar-collapse offset" id="navbarSupportedContent">
          <ul class="nav navbar-nav menu_nav ml-auto mr-auto">
            <li class="nav-item <?php if(Request::is('/')): ?> active <?php endif; ?>"><a class="nav-link" href="<?php echo e(route('home')); ?>">Inicio</a></li>
            <li class="nav-item <?php if(Request::is('nosotros')): ?> active <?php endif; ?>"><a class="nav-link" href="<?php echo e(route('about')); ?>">Nosotros</a></li>
            <li class="nav-item <?php if(Request::is('tienda')): ?> active <?php endif; ?>"><a class="nav-link" href="<?php echo e(route('product.index')); ?>">Tienda</a></li>
            <li class="nav-item <?php if(Request::is('preguntas-frecuentes')): ?> active <?php endif; ?>"><a class="nav-link" href="<?php echo e(route('FAQ')); ?>">Preguntas frecuentes</a></li>
            <li class="nav-item <?php if(Request::is('opiniones')): ?> active <?php endif; ?>"><a class="nav-link" href="<?php echo e(route('reviews')); ?>">Opiniones</a></li>
            <li class="nav-item <?php if(Request::is('contacto')): ?> active <?php endif; ?>"><a class="nav-link" href="<?php echo e(route('contact')); ?>">Contacto</a></li>
          </ul>

          <ul class="nav-shop">
            <!-- <li class="nav-item"><button><i class="ti-search"></i></button></li> -->
            <cart-component></cart-component>
            <?php echo $__env->make('partials.navigation.'.\App\User::navigation(), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- <li class="nav-item"><a href="<?php echo e(route('register')); ?>">Registrate</a></li> -->
          </ul>
        </div>
      </div>
    </nav>
  </div>
</header>
<!--================ End Header Menu Area =================<?php /**PATH C:\laragon\www\store\resources\views/shared/header.blade.php ENDPATH**/ ?>