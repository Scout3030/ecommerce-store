<ul class="list">
	<li>
		5 Estrellas
		<i class="fa fa-star" style="color: #fbd600"></i>
		<i class="fa fa-star" style="color: #fbd600"></i>
		<i class="fa fa-star" style="color: #fbd600"></i>
		<i class="fa fa-star" style="color: #fbd600"></i>
		<i class="fa fa-star" style="color: #fbd600"></i> 01
	</li>
	<li>
		4 Estrellas
		<i class="fa fa-star" style="color: #fbd600"></i>
		<i class="fa fa-star" style="color: #fbd600"></i>
		<i class="fa fa-star" style="color: #fbd600"></i>
		<i class="fa fa-star" style="color: #fbd600"></i>
		<i class="fa fa-star"></i> 01
	</li>
	<li>
		3 Estrellas
		<i class="fa fa-star" style="color: #fbd600"></i>
		<i class="fa fa-star" style="color: #fbd600"></i>
		<i class="fa fa-star" style="color: #fbd600"></i>
		<i class="fa fa-star"></i>
		<i class="fa fa-star"></i> 01
	</li><li>
	2 Estrellas
	<i class="fa fa-star" style="color: #fbd600"></i>
	<i class="fa fa-star" style="color: #fbd600"></i>
	<i class="fa fa-star"></i>
	<i class="fa fa-star"></i>
	<i class="fa fa-star"></i> 01
</li><li>
1 Estrellas
<i class="fa fa-star" style="color: #fbd600"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i> 01
</li>
</ul><?php /**PATH C:\laragon\www\store\resources\views/partials/product/stars.blade.php ENDPATH**/ ?>