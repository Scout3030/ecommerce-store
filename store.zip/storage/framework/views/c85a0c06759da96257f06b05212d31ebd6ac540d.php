<?php $__env->startSection('content'); ?>

<?php echo $__env->make('shared.breadcrumb', ['title' => 'Checkout'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--================Checkout Area =================-->
<section class="checkout_area section-margin--small">
    <div class="container">
    	<?php if(auth()->guard()->guest()): ?>
        <div class="returning_customer">
            <div class="check_title">
                <h2>¿Tienes una cuenta? <a href="javascript:void(0)">Ingrese los datos de su cuenta para ingresar</a></h2>
            </div>
            <p>También puede comprar como invitado, vaya a la sección de Facturación y envío.</p>
            <form class="row contact_form" action="<?php echo e(route('login')); ?>" method="post" novalidate="novalidate">
                <?php echo csrf_field(); ?>
                <div class="col-md-6 form-group p_star">
                    <input type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Email" id="email" name="email" value="<?php echo e(old('email')); ?>">
                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="col-md-6 form-group p_star">
                    <input type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="password" name="password" placeholder="Contraseña" required>

                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="col-md-12 form-group">
                    <button type="submit" value="submit" class="button button-login">Ingresar</button>
                    <div class="creat_account">
                        <input type="checkbox" id="f-option" name="selector">
                        <label for="f-option">Remember me</label>
                    </div>
                    <a class="lost_pass" href="<?php echo e(route('password.request')); ?>">¿Olvidaste tu contraseña?</a>
                </div>
            </form>
        </div>
        <?php endif; ?>
        <billing-component></billing-component>
    </div>
</section>
<!--================End Checkout Area =================-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\store\resources\views/checkout.blade.php ENDPATH**/ ?>