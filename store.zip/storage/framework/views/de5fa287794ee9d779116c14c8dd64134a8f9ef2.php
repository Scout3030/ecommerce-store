<div class="col-lg-4">
	<div class="blog_right_sidebar">
		<aside class="single_sidebar_widget author_widget">
			<img class="author_img rounded-circle" src="<?php echo e(asset('assets/img/blog/author.png')); ?>" alt="">
			<h3><?php echo e(App\Template::get()->first()->phone); ?></h3>
			<p>¿Tienes consultas?</p>
			<div class="social_icon">
				<a href="#">
					<i class="fab fa-facebook-f"></i>
				</a>
				<a href="#">
					<i class="fab fa-twitter"></i>
				</a>
				<a href="#">
					<i class="fab fa-github"></i>
				</a>
				<a href="#">
					<i class="fab fa-behance"></i>
				</a>
			</div>
			<p>Boot camps have its supporters andit sdetractors. Some people do not understand why you should
				have to spend money on boot camp when you can get. Boot camps have itssuppor ters andits
				detractors.
			</p>
			<div class="br"></div>
		</aside>
	</div>
</div><?php /**PATH C:\laragon\www\store\resources\views/partials/contact/card.blade.php ENDPATH**/ ?>