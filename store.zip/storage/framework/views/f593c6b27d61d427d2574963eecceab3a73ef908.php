<?php $__env->startSection('content'); ?>

<?php echo $__env->make('shared.breadcrumb', ['title' => 'Tienda'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- ================ category section start ================= -->
<section class="section-margin--small mb-5">
<div class="container">
  <div class="row">
    <div class="col-xl-3 col-lg-4 col-md-5">

      <categories-filter></categories-filter>
      <colors-filter></colors-filter>

    </div>

    <filter-component></filter-component>

  </div>
</div>
</section>
<!-- ================ category section end ================= -->

<!-- ================ top product area start ================= -->
<section class="related-product-area">
	<div class="container">
		<div class="section-intro pb-60px">
    <p>Productos más populares</p>
    <h2>Productos <span class="section-intro__style"> Top</span></h2>
  </div>
		<div class="row mt-30">

      <?php echo $__env->make('shared.footer-products', $products = $topProducts, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
	</div>
</section>
<!-- ================ top product area end ================= -->

<!-- ================ Subscribe section start ================= -->
<?php echo $__env->make('shared.newsletter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ================ Subscribe section end ================= -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('assets/vendors/nouislider/nouislider.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\store\resources\views/product/index.blade.php ENDPATH**/ ?>