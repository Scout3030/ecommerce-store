<?php $__currentLoopData = $products->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-sm-6 col-xl-3 mb-4 mb-xl-0">
    <div class="single-search-product-wrapper">
      <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="single-search-product d-flex">
        <a href="<?php echo e(route('product.show', $product->slug)); ?>" target="_BLANK"><img src="<?php echo e($product->pathAttachment()); ?>" alt=""></a>
        <div class="desc">
          <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="title" target="_BLANK"><?php echo e($product->name); ?></a>
          <div class="price">S/<?php echo e($product->price); ?></div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\store\resources\views/shared/footer-products.blade.php ENDPATH**/ ?>