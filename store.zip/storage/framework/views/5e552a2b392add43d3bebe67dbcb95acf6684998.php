<?php $__env->startSection('content'); ?>

<?php echo $__env->make('shared.breadcrumb', ['title' => 'Registro'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--================Login Box Area =================-->
<section class="login_box_area section-margin">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="login_box_img">
                    <div class="hover">
                        <h4>¿Eres nuevo en nuestra web?</h4>
                        <p>Encuentra cientos de materiales para tus productos</p>
                        <a class="button button-account" href="<?php echo e(route('register')); ?>">Crea una cuenta</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="login_form_inner">
                    <h3>Ingresa</h3>
                    <form method="POST" action="<?php echo e(route('login')); ?>" class="row login_form" id="contactForm" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="col-md-12 form-group">
                            <input type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required autofocus autocomplete="email">

                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <div class="col-md-12 form-group">
                            <input type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="password" name="password" placeholder="Contraseña" required>

                            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                        </div>
                        <div class="col-md-12 form-group">
                            <div class="creat_account">

                                <input type="checkbox" name="selector" id="f-option2" <?php echo e(old('selector') ? 'checked' : ''); ?>>

                                <label class="form-check-label" for="f-option2">
                                    Mantener sesión iniciada
                                </label>
                            </div>
                        </div>
                        <div class="col-md-12 form-group">
                            <button type="submit" value="submit" class="button button-login w-100">Ingresar</button>
                            <a href="<?php echo e(route('password.request')); ?>">
                                ¿Olvidaste tu contraseña?
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================End Login Box Area =================-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\store\resources\views/auth/login.blade.php ENDPATH**/ ?>