<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Shipping extends Model {
	const PUBLISHED = 1;
	const UNPUBLISHED = 2;
}
