export default {
	selectedCategory: null,
	selectedColor: null,
	selectedWord: '',
	selectedUrl: '/api/search' 
}