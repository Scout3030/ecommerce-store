export default {
	shippingMethods: [],
	selectedSHippingMethod: null,
	shippingCost: 10
}