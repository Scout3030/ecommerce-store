export default {
	paymentMethods: [],
	paymentMethod: null
}