export default {
	colors: []
}