export default {
	products: []
}