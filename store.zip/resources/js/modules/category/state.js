export default {
	categories: []
}