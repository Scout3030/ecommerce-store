export default {
	selectedCoupon: {
		value: 0
	}
}