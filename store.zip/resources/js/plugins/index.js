require('./axios')
require('./vuelidate')
require('./global')