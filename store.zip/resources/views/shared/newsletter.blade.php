<section class="subscribe-position">
  <div class="container">
    <div class="subscribe text-center">
      <h3 class="subscribe__title">Mantente actualizado</h3>
      <p>Recibe información sobre ofertas y promociones directamente en tu correo electrónico</p>
      <div id="mc_embed_signup">
        <newsletter-component></newsletter-component>
      </div>
    </div>
  </div>
</section>