<i class="fa fa-star {{ $rating >= 1 ? ' yellow' : '' }}"></i>
<i class="fa fa-star {{ $rating >= 2 ? ' yellow' : '' }}"></i>
<i class="fa fa-star {{ $rating >= 3 ? ' yellow' : '' }}"></i>
<i class="fa fa-star {{ $rating >= 4 ? ' yellow' : '' }}"></i>
<i class="fa fa-star {{ $rating >= 5 ? ' yellow' : '' }}"></i>